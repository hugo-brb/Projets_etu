# Orange-Business

Ce référentiel contient le code source et les ressources pour le site web de l'entreprise Orange-Business.

## Description

Ce site web Orange-Business est conçu pour les étudiants et les collégiens. Il fournit des informations sur les secteurs où Orange Business est présent, les services qu'ils proposent et les opportunités d'emplois offertes par l'entreprise.

## Fonctionnalités

- Présentation des services
- Présentation des secteurs d'activités
- Formulaire de contact
- Infos pratiques

## Installation

1. Clonez ce référentiel sur votre machine locale.
2. Ouvrez le fichier `index.html` dans votre navigateur web.

## Contribuer

Les contributions sont les bienvenues ! Si vous souhaitez apporter des améliorations au site web, veuillez suivre les étapes suivantes :

1. Fork ce référentiel.
2. Créez une branche pour vos modifications.
3. Effectuez vos modifications.
4. Soumettez une demande d'extraction.

## Auteurs

- Hugo BARBIERI
- Titouan RAULT
- Cyrian TORREJON

## Licence

Ce projet est entièrement dévellopé et pensé par les auteurs. @2023-2024 ALL RIGHT RESERVED.
