<?php
  // récupérer les données du formulaire
  $nom = htmlspecialchars($_POST['name']);
  $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
  $objet = htmlspecialchars($_POST['objet']);
  $message = htmlspecialchars($_POST['message']);
  // construire le corps de l'e-mail
  $body = "Nom : $nom\n\nEmail : $adresse\n\nObjet : $objet\n\n\nMessage :\n$message";
  // envoyer l'e-mail
  mail("hugobarbieri38@gmail.com.com","Contact - ORANGE BUSINESS", $body, "");
  // rediriger l'utilisateur vers une page de confirmation
  header('Location: confirmation.html');
?>
