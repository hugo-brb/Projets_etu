--> Pour que le formulaire fonctionne le site a besoin d'utiliser un serveur SMTP. (Ou d'être hébergé chez un hébergeur web possédant déjà un serveur SMTP ; ex : Hostinger, IONOS...)

--> Lors de l'envoi d'un formulaire si cela fonctionne, une page de confirmation indique à l'utilisateur que la demande a bien été prise en compte.

--> Pour accéder à cette page sans avoir à envoyer un formulaire, il faut saisir le lien suivant : .../MAIL/confirmation.html
	ex : file:///C:/Users/hugo/Desktop/D1-OrangeBusiness-site/Realisation/MAIL/confirmation.html